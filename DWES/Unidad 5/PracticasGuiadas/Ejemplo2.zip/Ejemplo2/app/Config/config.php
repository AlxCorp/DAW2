<?php 
define("DIRBASEURL", "/Unidad%205/PracticasGuiadas/Ejemplo2/public/index.php");
define("DIRPUBLIC", "/Unidad%205/PracticasGuiadas/Ejemplo2/public/")
?>