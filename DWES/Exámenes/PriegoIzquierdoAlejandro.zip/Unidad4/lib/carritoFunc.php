<?php 
function primeraCompra(){
    setcookie("he_comprado", 1, time()+60*60*60, "/");
    if (!isset($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }
}

function verProductos() {
    return $_SESSION['carrito'];
}

function agregarProducto($tipoProducto, $producto, $cantidad, $tamano) {
    array_push($_SESSION['carrito'], [$tipoProducto, $producto, $cantidad, $tamano]);
}
?>